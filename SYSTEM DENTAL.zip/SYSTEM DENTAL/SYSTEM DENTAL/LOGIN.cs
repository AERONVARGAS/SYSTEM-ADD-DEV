﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace SYSTEM_DENTAL
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnlogin_Click(object sender, EventArgs e)
        {
            if (txbUserId.Text == "admin" & txbpassword.Text == "pass")
            {
                MessageBox.Show("Welcome Admin. You are logged in successfully.");
                this.Visible = false;
                Home obj1 = new Home();
                obj1.ShowDialog();
              
            }
            else
            {
                MessageBox.Show("Invalid Username Or Password.");
            }

        }
    }
}
