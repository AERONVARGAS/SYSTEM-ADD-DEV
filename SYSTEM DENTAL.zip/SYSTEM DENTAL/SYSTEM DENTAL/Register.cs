﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SYSTEM_DENTAL
{
    internal static class Register
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
        }


        public static int setPatientID = 0;
        public static string setName = "";
        public static string setgender = "";
        public static int setAge = 0;
        public static string setBirth = "";
        public static long setContact = 0;
        public static string setAddress = "";
        public static string setEmail = "";
        public static string setWork = "";
        public static string setMOP = "";
        public static string setCivil = "";
        public static string setProcedure = "";

    }
}
