﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SYSTEM_DENTAL;

namespace WindowsFormsApp1
{
    public partial class PatientInformation : Form
    {
      
        public PatientInformation()
        {
            InitializeComponent();
           
        }

        private void PatientInformation_Load(object sender, EventArgs e)
        {
            txb2Patient.Text = Register.setPatientID.ToString();
            txb2Name.Text = Register.setName.ToString();
            txbGender.Text = Register.setgender.ToString();
            txb2Age.Text = Register.setAge.ToString();
            txbBirth.Text = Register.setBirth.ToString();
            txb2Address.Text = Register.setAddress.ToString();
            txb2ContactNo.Text = Register.setContact.ToString();
            txb2EmailAdd.Text = Register.setEmail.ToString();
            txb2MOP.Text = Register.setMOP.ToString();
            txb2Occupation.Text = Register.setWork.ToString();
            txb2Civil.Text = Register.setCivil.ToString();
            txb2Procedure.Text = Register.setProcedure.ToString();               
        }
        private void btn2Back_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Close();

        }
    }
}
