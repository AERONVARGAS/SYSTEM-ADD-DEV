﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using SYSTEM_DENTAL;

namespace WindowsFormsApp1
{
    public partial class PatientRegistration : Form
    {
        private static int _PatientID;
        private static string _PatientName;
        private static int _Age;
        private static long _Contact;
        private static string _Address;
        private static string _Email;
        private static string _Work;

        public int PatientID (string ID) 
        { 
            _PatientID = Int32.Parse(ID);
            return _PatientID;
        }
        public string PatientName(string name) 
        {
            if (Regex.IsMatch(name, @"^[a-zA-Z]+&"))
            {
               _PatientName = name;
            }
            return _PatientName;
        }  
         public int Age(string age)
        {
            _Age = Int32.Parse(age);
            return _Age;
        }
        public long Contact(string Con)
        {
            _Contact = long.Parse(Con);
             return _Contact;
        }

        public string Address(string add)
        {
            if(Regex.IsMatch(add, @"^[a-zA-Z]+&"))
            {
                _Address = add;
            }
            return _Address;
        }
          
        public string Email(string email)
        {
            if (Regex.IsMatch(email, @"^[a-zA-Z]+&"))
            {
                _Email = email;
            }
            return _Email;
        }
        public string Work(string work) 
        {
            if (Regex.IsMatch(work, @"^[a-zA-Z]+&"))
            {
                _Work = work;
            }
            return _Work;
        }
        public PatientRegistration()
        {
            InitializeComponent();
        }
        private void PatientRegistration_Load(object sender, EventArgs e)
        {
            string[] Gender = new string[]
            {
                "Male",
                "Famale"
            };
            for (int i = 0; i < Gender.Length; i++)
            {
                cbGender.Items.Add(Gender[i]);
            }


            string[] MOP = new string[]
            {
                "CASH",
                "GCASH",
                "CREDIT CARD"
            };
            for (int i = 0; i < MOP.Length; i++)
            {
                cbMOP.Items.Add(MOP[i]);
            }

            string[] civil = new string[]
            {
                "SINGLE",
                "MARRIED"
            };
            for (int i = 0; i < civil.Length; i++)
            {
                cbCivil.Items.Add(civil[i]);
            }

            string[] Procedure = new string[] {

             "Cleaning",
             "Pasta",
             "Brace",
             "Oral Hygiene",
             "Dentures",
             "Dental Surgery",
             "Dental Implants",
             "Dental Fillings",
             " Periodontology",
             "Cosmetic Whitening",
            };
            for (int i = 0; i < Procedure.Length; i++)
            {
                cbProcedure.Items.Add(Procedure[i]);
            }

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            Register.setPatientID = PatientID(txb1PatientID.Text);
            Register.setName = PatientName(txb1Name.Text);
            Register.setgender = cbGender.Text;
            Register.setAge = Age(txb1Age.Text);
            Register.setBirth = DatePickerBirth1.Value.ToString("yyyy-MM-dd");
            Register.setEmail = Email(txb1EmailAdd.Text);
            Register.setContact = Contact(txb1ContactNo.Text);
            Register.setAddress = Address(txb1Address.Text);
            Register.setWork = Work(txb1Occupation.Text);
            Register.setProcedure = cbProcedure.Text;
            Register.setCivil = cbCivil.Text;
            PatientInformation information = new PatientInformation();
            information.ShowDialog();
        }

        private void btn1Back_Click(object sender, EventArgs e)
        {
            Home home = new Home();
            home.Show();
            this.Close();
        }


    }
}