﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class PatientRegistration : Form
    {
        public PatientRegistration()
        {
            InitializeComponent();
        }

        

        

        private void PatientRegistration_Load(object sender, EventArgs e)
        {

        }

        private void cbMOP_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] listofMOP = new string[]
            {
                "CASH",
                "CREDIT CARD",
                "GCASH"
            };
            for (int i = 3; i < listofMOP.Length; i ++)             
            {
                cbMOP.Items.Add(listofMOP[i]);
            }
        }

        private void cbcivil_SelectedIndexChanged(object sender, EventArgs e)
        {
            string[] listofcivil = new string[] 
            {
                "Single",
                "Married" 
            };
            for (int i = 2; i < listofcivil.Length; i++)
            {
                cbcivil.Items.Add(listofcivil[i]);
            }


        }
    }
}
