﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace SYSTEM_DENTAL
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.Show();
            this.Close();
        }

        private void btnRegis_Click(object sender, EventArgs e)
        {
            PatientRegistration patient = new PatientRegistration();
            patient.Show();
            this.Close();
        }

        private void btnInfo_Click(object sender, EventArgs e)
        {
            PatientInformation information = new PatientInformation();
            information.Show();
            this.Close();
        }
    }
}
